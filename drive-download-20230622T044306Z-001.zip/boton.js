var check=document.querySelector(".check");
check.addEventListener('click',idioma);

function idioma(){
    let id=check.checked
    if (id==true){
        location.href="Pagina principal.html"
    }
    else{
        location.href="Main page.html"
    }
}